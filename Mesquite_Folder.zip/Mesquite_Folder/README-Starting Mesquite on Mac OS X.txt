To Run Mesquite on Mac OS X

To run Mesquite, you need Java installed.  The version of Mesquite you have here runs on Java 1.7, 1.8, or higher.  This is the recommended version of Java for running on Mac OS X 10.10 (Yosemite) or higher.

Once Mesquite_Folder is installed, you can start Mesquite by double clicking Mesquite.app, which has the icon with the mesquite leaf in the black box.  This default app asks for 1 GB of memory.

In the folder OtherWaysToStartMesquite are other apps and script files to start Mesquite. Inside of OtherWaysToStartMesquite, you will see 6 apps with the icon with a mesquite leaf in a black rectangle.  To use one of them (for instance, Mequite (2GB).app), move it to be beside the default Mesquite.app, in Mesquite_Folder.  Then, double clicking it should start Mesquite. 

In selecting which app to use, you have two basic choices to make: the amount of memory to use, and whether or not to use the Quartz graphics system. The default app uses 1 GB, but we offer one asking for more memory (2GB), and one asking for less (500BM).  The default app does NOT use Quartz, which means its graphics are clearer, but slower.  If you want faster graphics, try using one of the apps that uses Quartz.

If you want even more memory, or you need full control over Mesquite starting, or if the apps don't work, try moving the file Mesquite_Start_Script.command (in OtherWaysToStartMesquite) to be beside Mesquite.app, in Mesquite_Folder.  Double clicking that script file will start Mesquite.  If double clicking this file does not start Mesquite, select the file in the Finder, choose Get Info, and change the "Open With" to "Terminal.app", which is in /Applications/Utilities/

You can also edit this script file to change Mesquite's running conditions.

To give Mesquite even more memory, open the file with a text editor and edit the line:

   java  -Xmx4000M -Xss2m -Djava.library.path=lib -cp . mesquite.Mesquite

The part -Xmx4000M indicates how much heap memory to give to Mesquite in general. With more heap memory Mesquite can handle more trees, bigger matrices, bigger charts, and so on.

The part -Xss2m indicates how much stack memory to give to each thread.  With more stack memory, Mesquite can handle bigger trees, e.g. more than 5000 taxa.  To be able to handle 10000 taxa, you may need to increase this to 4m.

If you change these settings, make sure you don't introduce any spaces.


